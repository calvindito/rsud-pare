-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 23 Jan 2023 pada 09.49
-- Versi server: 10.4.27-MariaDB
-- Versi PHP: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rsud_clone`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `dm_tindakan`
--

CREATE TABLE `dm_tindakan` (
  `id` int(11) NOT NULL,
  `kode` char(4) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `biaya` double NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `dm_tindakan`
--

INSERT INTO `dm_tindakan` (`id`, `kode`, `nama`, `biaya`, `created_at`, `updated_at`) VALUES
(1, 'A001', 'Cek Umum', 15000, '2018-11-27 11:52:49', '2018-11-28 10:07:23'),
(2, 'K001', 'Konsul', 22500, NULL, '2019-07-25 07:47:56'),
(3, 'T001', 'Tindakan Kecil 1', 0, '2019-07-25 04:20:24', '2019-07-25 04:20:24'),
(4, 'T002', 'Tindakan Kecil 2', 0, '2019-07-25 04:20:56', '2019-07-25 04:20:56'),
(5, 'T003', 'Tindakan Kecil 3', 0, '2019-07-25 04:21:21', '2019-07-25 04:21:21'),
(6, 'T004', 'Rawat Luka Kecil', 0, '2019-07-25 04:22:07', '2019-07-25 04:22:07'),
(7, 'T005', 'Rawat Luka Sedang', 0, '2019-07-25 04:22:26', '2019-07-25 04:22:26'),
(8, 'T006', 'Rawat Luka Besar', 0, '2019-07-25 04:22:45', '2019-07-25 04:22:45'),
(9, 'T007', 'Bersihkan telingan', 100000, '2020-02-13 02:06:20', '2020-02-13 02:06:20'),
(10, 'T008', 'TINDAKAN RINGAN 1', 43000, '2020-07-03 01:32:17', '2020-07-03 01:32:17'),
(11, 'T009', 'TINDAKAN RINGAN 2', 75000, '2020-07-03 01:32:40', '2020-07-03 01:32:40'),
(12, 'T010', 'TINDAKAN RINGAN 3', 112500, '2020-07-03 01:33:03', '2020-07-03 01:33:03'),
(13, 'T011', 'TINDAKAN RINGAN 4', 150000, '2020-07-03 02:15:11', '2020-07-03 02:15:11'),
(14, 'T012', 'TINDAKAN OPERATIF KECIL 1', 225000, '2020-07-03 02:16:04', '2020-07-03 02:16:04'),
(15, 'T013', 'TINDAKAN OPERATIF KECIL 2', 600000, '2020-07-03 02:16:20', '2020-07-03 02:16:20'),
(16, 'T014', 'TINDAKAN OPERATIF KECIL 3', 1200000, '2020-07-03 02:17:01', '2020-07-03 02:17:01'),
(17, 'T015', 'TINDAKAN OPERATIF KECIL 4', 1500000, '2020-07-03 02:17:25', '2020-07-03 02:17:25');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tindakan_medis_lain`
--

CREATE TABLE `tindakan_medis_lain` (
  `id_tindakan` int(11) NOT NULL,
  `nama_tindakan` varchar(255) NOT NULL,
  `kelas_id` int(11) NOT NULL,
  `bhp` double DEFAULT NULL,
  `jrs` double NOT NULL COMMENT 'dalam rupiah',
  `japel` double NOT NULL COMMENT 'dalam rupiah',
  `tarip` double NOT NULL,
  `param` varchar(255) NOT NULL COMMENT 'jenis tindakan, contoh : non operatif, bidan, gigi, dsb',
  `catatan` varchar(255) DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `tindakan_medis_lain`
--

INSERT INTO `tindakan_medis_lain` (`id_tindakan`, `nama_tindakan`, `kelas_id`, `bhp`, `jrs`, `japel`, `tarip`, `param`, `catatan`, `created`) VALUES
(35, 'Rekam Medis', 6, 0, 0, 0, 5500, '-', '-', '2017-01-17 16:04:40'),
(36, 'Penunggu Px', 6, 0, 0, 0, 2500, '-', '-', '2017-01-17 16:04:56'),
(38, 'Administrasi', 6, 0, 0, 0, 6000, '-', '-', '2017-01-17 16:05:11'),
(39, 'Pembinaan Rohani', 6, 0, 0, 0, 2500, '0', '-', '2017-01-19 03:56:17'),
(40, 'Materai', 6, 0, 0, 0, 6000, '-', '-', '2017-01-19 03:56:30'),
(41, 'Rekam Medis', 1, 0, 0, 0, 15000, '-', '-', '2017-01-17 09:04:40'),
(42, 'Penunggu Px', 1, 0, 0, 0, 11500, '-', '-', '2017-01-17 09:04:56'),
(43, 'Administrasi', 1, 0, 0, 0, 37500, '-', '-', '2017-01-17 09:05:11'),
(44, 'Pembinaan Rohani', 1, 0, 0, 0, 22500, '-', '-', '2017-01-18 20:56:17'),
(45, 'Materai', 1, 0, 0, 0, 6000, '-', '-', '2017-01-18 20:56:30'),
(46, 'Rekam Medis', 4, 0, 0, 0, 10500, '-', '-', '2017-01-17 09:04:40'),
(47, 'Penunggu Px', 4, 0, 0, 0, 6000, '-', '-', '2017-01-17 09:04:56'),
(48, 'Administrasi', 4, 0, 0, 0, 15000, '-', '-', '2017-01-17 09:05:11'),
(49, 'Pembinaan Rohani', 4, 0, 0, 0, 10500, '-', '-', '2017-01-18 20:56:17'),
(50, 'Materai', 4, 0, 0, 0, 6000, '-', '-', '2017-01-18 20:56:30'),
(51, 'Rekam Medis', 5, 0, 0, 0, 7000, '-', '-', '2017-01-17 09:04:40'),
(52, 'Penunggu Px', 5, 0, 0, 0, 4000, '-', '-', '2017-01-17 09:04:56'),
(53, 'Administrasi', 5, 0, 0, 0, 11500, '-', '-', '2017-01-17 09:05:11'),
(54, 'Pembinaan Rohani', 5, 0, 0, 0, 4000, '-', '-', '2017-01-18 20:56:17'),
(55, 'Materai', 5, 0, 0, 0, 6000, '-', '-', '2017-01-18 20:56:30'),
(56, 'Rekam Medis', 2, 0, 0, 0, 15000, '-', '-', '2017-01-17 02:04:40'),
(57, 'Penunggu Px', 2, 0, 0, 0, 11250, '-', '-', '2017-01-17 02:04:56'),
(58, 'Administrasi', 2, 0, 0, 0, 37000, '-', '-', '2017-01-17 02:05:11'),
(59, 'Pembinaan Rohani', 2, 0, 0, 0, 22500, '-', '-', '2017-01-18 13:56:17'),
(60, 'Materai', 2, 0, 0, 0, 6000, '-', '-', '2017-01-18 13:56:30'),
(61, 'Rekam Medis', 3, 0, 0, 0, 15000, '-', '-', '2017-01-17 02:04:40'),
(62, 'Penunggu Px', 3, 0, 0, 0, 11250, '-', '-', '2017-01-17 02:04:56'),
(63, 'Administrasi', 3, 0, 0, 0, 37000, '-', '-', '2017-01-17 02:05:11'),
(64, 'Pembinaan Rohani', 3, 0, 0, 0, 22500, '-', '-', '2017-01-18 13:56:17'),
(65, 'Materai', 3, 0, 0, 0, 6000, '-', '-', '2017-01-18 13:56:30'),
(66, 'Gelang', 1, 0, 0, 0, 1800, '-', '-', '2018-09-12 02:22:49'),
(67, 'Gelang', 2, 0, 0, 0, 1800, '-', '-', '2018-09-12 02:23:07'),
(68, 'Gelang', 4, 0, 0, 0, 1800, '-', '-', '2018-09-12 02:23:25'),
(69, 'Gelang', 5, 0, 0, 0, 1800, '-', '-', '2018-09-12 02:23:46'),
(70, 'Gelang', 6, 0, 0, 0, 1800, '0', '-', '2018-09-12 02:23:58'),
(71, 'Gelang', 3, 0, 0, 0, 1800, '-', '-', '2018-09-12 02:24:11'),
(72, 'Rekam Medis', 7, NULL, 0, 0, 7000, '0', '', '2020-01-02 07:55:07'),
(73, 'Materai', 7, NULL, 0, 0, 6000, '0', '', '2020-01-03 02:04:17'),
(74, 'Ambulance', 7, NULL, 0, 0, 0, '0', '', '2020-01-03 02:05:07');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tindakan_medis_non_operatif`
--

CREATE TABLE `tindakan_medis_non_operatif` (
  `id_tindakan` int(11) NOT NULL,
  `kode_tindakan` varchar(20) NOT NULL DEFAULT '-',
  `nama_tindakan` varchar(255) NOT NULL,
  `kelas_id` int(11) NOT NULL,
  `jrs` double NOT NULL COMMENT 'dalam persentase',
  `drOP` double NOT NULL COMMENT 'value dibagi dengan 177 dikalikan total',
  `drANAS` double NOT NULL COMMENT 'value dibagi dengan 177 dikalikan total',
  `perawatOK` double NOT NULL COMMENT 'value dibagi dengan 177 dikalikan total',
  `perawatANAS` double NOT NULL COMMENT 'value dibagi dengan 177 dikalikan total',
  `total` double NOT NULL COMMENT 'dalam persentase',
  `tarip` double NOT NULL,
  `created` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `tindakan_medis_non_operatif`
--

INSERT INTO `tindakan_medis_non_operatif` (`id_tindakan`, `kode_tindakan`, `nama_tindakan`, `kelas_id`, `jrs`, `drOP`, `drANAS`, `perawatOK`, `perawatANAS`, `total`, `tarip`, `created`) VALUES
(2, 'jrm', 'Jasa Rumah Sakit', 6, 0, 0, 0, 0, 0, 0, 0, '2017-01-13 23:33:57'),
(3, 'jm', 'Jasa Medik', 6, 0, 0, 0, 0, 0, 0, 0, '2017-01-13 23:33:57'),
(6, 'japel', 'Jasa Pelayanan Perawatan', 6, 0, 0, 0, 0, 0, 0, 0, '2017-01-13 23:33:57'),
(7, 'monitor', 'Monitor ', 6, 0, 0, 0, 0, 0, 0, 0, '2018-09-13 03:10:51'),
(8, 'ponek', 'Ponek', 6, 0, 0, 0, 0, 0, 0, 0, '2018-09-13 03:11:21'),
(9, 'rr', 'Recovery Room', 6, 0, 0, 0, 0, 0, 0, 0, '2019-03-29 06:29:12');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tindakan_medis_operatif`
--

CREATE TABLE `tindakan_medis_operatif` (
  `id_tindakan` int(11) NOT NULL,
  `nama_tindakan` varchar(255) NOT NULL,
  `kode_tindakan` varchar(10) NOT NULL,
  `kelas_id` int(11) NOT NULL,
  `jrs` double NOT NULL COMMENT 'dalam persentase',
  `drOP` double NOT NULL COMMENT 'value dibagi dengan 177 dikalikan total',
  `drANAS` double NOT NULL COMMENT 'value dibagi dengan 177 dikalikan total',
  `perawatOK` double NOT NULL COMMENT 'value dibagi dengan 177 dikalikan total',
  `perawatANAS` double NOT NULL COMMENT 'value dibagi dengan 177 dikalikan total',
  `total` double NOT NULL COMMENT 'dalam persentase',
  `tarip` double NOT NULL,
  `created` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `tindakan_medis_operatif`
--

INSERT INTO `tindakan_medis_operatif` (`id_tindakan`, `nama_tindakan`, `kode_tindakan`, `kelas_id`, `jrs`, `drOP`, `drANAS`, `perawatOK`, `perawatANAS`, `total`, `tarip`, `created`) VALUES
(7, 'Bahan Habis Pakai RR', 'BHP', 6, 0, 0, 0, 0, 0, 0, 0, '2017-01-14 06:32:42'),
(8, 'Jasa Rumah Sakit', 'JRS', 6, 0, 0, 0, 0, 0, 0, 0, '2017-01-14 06:33:57'),
(9, 'Jasa Medik', 'JMO', 6, 0, 0, 0, 0, 0, 0, 0, '2017-01-14 06:33:57'),
(10, 'JM Anestesi', 'JMA', 6, 0, 0, 0, 0, 0, 0, 0, '2017-01-14 06:33:57'),
(11, 'JM Prwt Anestesi', 'JPA', 6, 0, 0, 0, 0, 0, 0, 0, '2017-01-14 06:33:57'),
(12, 'J-Pel Perawatan OK', 'JPO', 6, 0, 0, 0, 0, 0, 0, 0, '2017-01-14 06:33:57'),
(13, 'RR-Askep', 'RRA', 6, 0, 0, 0, 0, 0, 0, 0, '2017-01-19 03:43:19'),
(14, 'RR-Mntr', 'RRM', 6, 0, 0, 0, 0, 0, 0, 0, '2017-01-19 03:43:27'),
(15, 'Bahan Habis Pakai OK', 'BHP', 6, 0, 0, 0, 0, 0, 0, 0, '2019-02-21 07:48:25');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tindakan_medis_penunjang`
--

CREATE TABLE `tindakan_medis_penunjang` (
  `id_tindakan_penunjang` int(11) NOT NULL,
  `nama_tindakan` varchar(255) NOT NULL,
  `kelas_id` int(11) NOT NULL,
  `bhp` double DEFAULT 0,
  `jrs` double DEFAULT 0 COMMENT 'dalam rupiah',
  `japel` double DEFAULT 0 COMMENT 'dalam rupiah',
  `tarip` double DEFAULT 0,
  `param` varchar(255) DEFAULT NULL COMMENT 'jenis tindakan, contoh : non operatif, bidan, gigi, dsb',
  `catatan` varchar(255) DEFAULT NULL,
  `created` timestamp NULL DEFAULT current_timestamp(),
  `jenis_penunjang` int(11) DEFAULT 1 COMMENT '0 = radiologi, 1= yg lain, 2 = patoklinik, 3 = patoanatomi'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `tindakan_medis_penunjang`
--

INSERT INTO `tindakan_medis_penunjang` (`id_tindakan_penunjang`, `nama_tindakan`, `kelas_id`, `bhp`, `jrs`, `japel`, `tarip`, `param`, `catatan`, `created`, `jenis_penunjang`) VALUES
(27, 'USG', 6, 0, 0, 0, 0, '-', '-', '2017-10-03 08:51:08', 0),
(28, 'Foto', 6, 0, 0, 0, 0, '-', '-', '2017-01-14 06:54:07', 0),
(29, 'CT SCAN', 6, 0, 0, 0, 0, '-', '-', '2017-01-14 06:55:20', 0),
(30, 'Laboratorium', 6, 0, 0, 0, 0, '-', '-', '2017-01-14 06:55:20', 2),
(31, 'EKG', 6, 0, 0, 0, 0, '-', '-', '2017-01-14 06:55:20', 1),
(32, 'HD', 6, 0, 0, 0, 0, '-', '-', '2017-01-14 06:55:20', 4),
(33, 'PA', 6, 0, 0, 0, 0, '-', '-', '2017-01-14 06:55:20', 3),
(34, 'Rehab Medik', 6, 0, 0, 0, 0, '-', '-', '2017-01-14 06:55:20', 1),
(35, 'VISUM', 6, 0, 0, 0, 31500, '-', '-', '2017-09-07 04:01:39', 1),
(36, 'C-Arm', 6, 0, 0, 0, 0, NULL, NULL, '2019-11-25 13:02:25', 1),
(37, 'Mammografi', 6, 0, 0, 0, 0, NULL, NULL, '2019-11-25 13:02:46', 1),
(38, 'Panoramic', 6, 0, 0, 0, 0, NULL, NULL, '2019-11-25 13:02:57', 1),
(39, 'Polos', 6, 0, 0, 0, 0, NULL, NULL, '2019-11-25 13:03:04', 1),
(40, 'Radiografi Kontras', 6, 0, 0, 0, 0, NULL, NULL, '2019-11-25 13:03:13', 1),
(41, 'Radiografi Polos', 6, 0, 0, 0, 0, NULL, NULL, '2019-11-25 13:03:22', 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tindakan_rawat_darurat`
--

CREATE TABLE `tindakan_rawat_darurat` (
  `id_tindakan` int(11) NOT NULL,
  `nama_tindakan` varchar(255) DEFAULT NULL,
  `jrs` double DEFAULT NULL,
  `japel_dokter` double DEFAULT NULL,
  `japel_askep` double DEFAULT NULL,
  `tarip` double DEFAULT NULL,
  `catatan` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `tindakan_rawat_darurat`
--

INSERT INTO `tindakan_rawat_darurat` (`id_tindakan`, `nama_tindakan`, `jrs`, `japel_dokter`, `japel_askep`, `tarip`, `catatan`) VALUES
(1, 'Pemeriksaan', 12000, 12000, 12000, 36000, NULL),
(2, 'Observasi', 19200, 6400, 6400, 32000, NULL),
(3, 'Kecil', 1440, 1440, 1120, 4000, 'Tindakan Medis'),
(4, 'Pengawasan Dokter', 0, 0, 0, 44000, NULL);

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `dm_tindakan`
--
ALTER TABLE `dm_tindakan`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indeks untuk tabel `tindakan_medis_lain`
--
ALTER TABLE `tindakan_medis_lain`
  ADD PRIMARY KEY (`id_tindakan`) USING BTREE,
  ADD KEY `tindakan_medis_lain_ibfk_1` (`kelas_id`) USING BTREE;

--
-- Indeks untuk tabel `tindakan_medis_non_operatif`
--
ALTER TABLE `tindakan_medis_non_operatif`
  ADD PRIMARY KEY (`id_tindakan`) USING BTREE,
  ADD KEY `tindakan_medis_operatif_ibfk_1` (`kelas_id`) USING BTREE;

--
-- Indeks untuk tabel `tindakan_medis_operatif`
--
ALTER TABLE `tindakan_medis_operatif`
  ADD PRIMARY KEY (`id_tindakan`) USING BTREE,
  ADD KEY `tindakan_medis_operatif_ibfk_1` (`kelas_id`) USING BTREE;

--
-- Indeks untuk tabel `tindakan_medis_penunjang`
--
ALTER TABLE `tindakan_medis_penunjang`
  ADD PRIMARY KEY (`id_tindakan_penunjang`) USING BTREE,
  ADD KEY `tindakan_medis_penunjang_ibfk_1` (`kelas_id`) USING BTREE;

--
-- Indeks untuk tabel `tindakan_rawat_darurat`
--
ALTER TABLE `tindakan_rawat_darurat`
  ADD PRIMARY KEY (`id_tindakan`) USING BTREE;

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `dm_tindakan`
--
ALTER TABLE `dm_tindakan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT untuk tabel `tindakan_medis_lain`
--
ALTER TABLE `tindakan_medis_lain`
  MODIFY `id_tindakan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=75;

--
-- AUTO_INCREMENT untuk tabel `tindakan_medis_non_operatif`
--
ALTER TABLE `tindakan_medis_non_operatif`
  MODIFY `id_tindakan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT untuk tabel `tindakan_medis_operatif`
--
ALTER TABLE `tindakan_medis_operatif`
  MODIFY `id_tindakan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT untuk tabel `tindakan_medis_penunjang`
--
ALTER TABLE `tindakan_medis_penunjang`
  MODIFY `id_tindakan_penunjang` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT untuk tabel `tindakan_rawat_darurat`
--
ALTER TABLE `tindakan_rawat_darurat`
  MODIFY `id_tindakan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `tindakan_medis_lain`
--
ALTER TABLE `tindakan_medis_lain`
  ADD CONSTRAINT `tindakan_medis_lain_ibfk_1` FOREIGN KEY (`kelas_id`) REFERENCES `dm_kelas` (`id_kelas`);

--
-- Ketidakleluasaan untuk tabel `tindakan_medis_non_operatif`
--
ALTER TABLE `tindakan_medis_non_operatif`
  ADD CONSTRAINT `tindakan_medis_non_operatif_ibfk_1` FOREIGN KEY (`kelas_id`) REFERENCES `dm_kelas` (`id_kelas`);

--
-- Ketidakleluasaan untuk tabel `tindakan_medis_operatif`
--
ALTER TABLE `tindakan_medis_operatif`
  ADD CONSTRAINT `tindakan_medis_operatif_ibfk_1` FOREIGN KEY (`kelas_id`) REFERENCES `dm_kelas` (`id_kelas`);

--
-- Ketidakleluasaan untuk tabel `tindakan_medis_penunjang`
--
ALTER TABLE `tindakan_medis_penunjang`
  ADD CONSTRAINT `tindakan_medis_penunjang_ibfk_1` FOREIGN KEY (`kelas_id`) REFERENCES `dm_kelas` (`id_kelas`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
