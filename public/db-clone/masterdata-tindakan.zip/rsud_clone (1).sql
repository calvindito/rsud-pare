-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 23 Jan 2023 pada 09.51
-- Versi server: 10.4.27-MariaDB
-- Versi PHP: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rsud_clone`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `dm_tindakan`
--

CREATE TABLE `dm_tindakan` (
  `id` int(11) NOT NULL,
  `kode` char(4) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `biaya` double NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `dm_tindakan`
--

INSERT INTO `dm_tindakan` (`id`, `kode`, `nama`, `biaya`, `created_at`, `updated_at`) VALUES
(1, 'A001', 'Cek Umum', 15000, '2018-11-27 11:52:49', '2018-11-28 10:07:23'),
(2, 'K001', 'Konsul', 22500, NULL, '2019-07-25 07:47:56'),
(3, 'T001', 'Tindakan Kecil 1', 0, '2019-07-25 04:20:24', '2019-07-25 04:20:24'),
(4, 'T002', 'Tindakan Kecil 2', 0, '2019-07-25 04:20:56', '2019-07-25 04:20:56'),
(5, 'T003', 'Tindakan Kecil 3', 0, '2019-07-25 04:21:21', '2019-07-25 04:21:21'),
(6, 'T004', 'Rawat Luka Kecil', 0, '2019-07-25 04:22:07', '2019-07-25 04:22:07'),
(7, 'T005', 'Rawat Luka Sedang', 0, '2019-07-25 04:22:26', '2019-07-25 04:22:26'),
(8, 'T006', 'Rawat Luka Besar', 0, '2019-07-25 04:22:45', '2019-07-25 04:22:45'),
(9, 'T007', 'Bersihkan telingan', 100000, '2020-02-13 02:06:20', '2020-02-13 02:06:20'),
(10, 'T008', 'TINDAKAN RINGAN 1', 43000, '2020-07-03 01:32:17', '2020-07-03 01:32:17'),
(11, 'T009', 'TINDAKAN RINGAN 2', 75000, '2020-07-03 01:32:40', '2020-07-03 01:32:40'),
(12, 'T010', 'TINDAKAN RINGAN 3', 112500, '2020-07-03 01:33:03', '2020-07-03 01:33:03'),
(13, 'T011', 'TINDAKAN RINGAN 4', 150000, '2020-07-03 02:15:11', '2020-07-03 02:15:11'),
(14, 'T012', 'TINDAKAN OPERATIF KECIL 1', 225000, '2020-07-03 02:16:04', '2020-07-03 02:16:04'),
(15, 'T013', 'TINDAKAN OPERATIF KECIL 2', 600000, '2020-07-03 02:16:20', '2020-07-03 02:16:20'),
(16, 'T014', 'TINDAKAN OPERATIF KECIL 3', 1200000, '2020-07-03 02:17:01', '2020-07-03 02:17:01'),
(17, 'T015', 'TINDAKAN OPERATIF KECIL 4', 1500000, '2020-07-03 02:17:25', '2020-07-03 02:17:25');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tindakan_medis_lain`
--

CREATE TABLE `tindakan_medis_lain` (
  `id_tindakan` int(11) NOT NULL,
  `nama_tindakan` varchar(255) NOT NULL,
  `kelas_id` int(11) NOT NULL,
  `bhp` double DEFAULT NULL,
  `jrs` double NOT NULL COMMENT 'dalam rupiah',
  `japel` double NOT NULL COMMENT 'dalam rupiah',
  `tarip` double NOT NULL,
  `param` varchar(255) NOT NULL COMMENT 'jenis tindakan, contoh : non operatif, bidan, gigi, dsb',
  `catatan` varchar(255) DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `tindakan_medis_lain`
--

INSERT INTO `tindakan_medis_lain` (`id_tindakan`, `nama_tindakan`, `kelas_id`, `bhp`, `jrs`, `japel`, `tarip`, `param`, `catatan`, `created`) VALUES
(35, 'Rekam Medis', 6, 0, 0, 0, 5500, '-', '-', '2017-01-17 16:04:40'),
(36, 'Penunggu Px', 6, 0, 0, 0, 2500, '-', '-', '2017-01-17 16:04:56'),
(38, 'Administrasi', 6, 0, 0, 0, 6000, '-', '-', '2017-01-17 16:05:11'),
(39, 'Pembinaan Rohani', 6, 0, 0, 0, 2500, '0', '-', '2017-01-19 03:56:17'),
(40, 'Materai', 6, 0, 0, 0, 6000, '-', '-', '2017-01-19 03:56:30'),
(41, 'Rekam Medis', 1, 0, 0, 0, 15000, '-', '-', '2017-01-17 09:04:40'),
(42, 'Penunggu Px', 1, 0, 0, 0, 11500, '-', '-', '2017-01-17 09:04:56'),
(43, 'Administrasi', 1, 0, 0, 0, 37500, '-', '-', '2017-01-17 09:05:11'),
(44, 'Pembinaan Rohani', 1, 0, 0, 0, 22500, '-', '-', '2017-01-18 20:56:17'),
(45, 'Materai', 1, 0, 0, 0, 6000, '-', '-', '2017-01-18 20:56:30'),
(46, 'Rekam Medis', 4, 0, 0, 0, 10500, '-', '-', '2017-01-17 09:04:40'),
(47, 'Penunggu Px', 4, 0, 0, 0, 6000, '-', '-', '2017-01-17 09:04:56'),
(48, 'Administrasi', 4, 0, 0, 0, 15000, '-', '-', '2017-01-17 09:05:11'),
(49, 'Pembinaan Rohani', 4, 0, 0, 0, 10500, '-', '-', '2017-01-18 20:56:17'),
(50, 'Materai', 4, 0, 0, 0, 6000, '-', '-', '2017-01-18 20:56:30'),
(51, 'Rekam Medis', 5, 0, 0, 0, 7000, '-', '-', '2017-01-17 09:04:40'),
(52, 'Penunggu Px', 5, 0, 0, 0, 4000, '-', '-', '2017-01-17 09:04:56'),
(53, 'Administrasi', 5, 0, 0, 0, 11500, '-', '-', '2017-01-17 09:05:11'),
(54, 'Pembinaan Rohani', 5, 0, 0, 0, 4000, '-', '-', '2017-01-18 20:56:17'),
(55, 'Materai', 5, 0, 0, 0, 6000, '-', '-', '2017-01-18 20:56:30'),
(56, 'Rekam Medis', 2, 0, 0, 0, 15000, '-', '-', '2017-01-17 02:04:40'),
(57, 'Penunggu Px', 2, 0, 0, 0, 11250, '-', '-', '2017-01-17 02:04:56'),
(58, 'Administrasi', 2, 0, 0, 0, 37000, '-', '-', '2017-01-17 02:05:11'),
(59, 'Pembinaan Rohani', 2, 0, 0, 0, 22500, '-', '-', '2017-01-18 13:56:17'),
(60, 'Materai', 2, 0, 0, 0, 6000, '-', '-', '2017-01-18 13:56:30'),
(61, 'Rekam Medis', 3, 0, 0, 0, 15000, '-', '-', '2017-01-17 02:04:40'),
(62, 'Penunggu Px', 3, 0, 0, 0, 11250, '-', '-', '2017-01-17 02:04:56'),
(63, 'Administrasi', 3, 0, 0, 0, 37000, '-', '-', '2017-01-17 02:05:11'),
(64, 'Pembinaan Rohani', 3, 0, 0, 0, 22500, '-', '-', '2017-01-18 13:56:17'),
(65, 'Materai', 3, 0, 0, 0, 6000, '-', '-', '2017-01-18 13:56:30'),
(66, 'Gelang', 1, 0, 0, 0, 1800, '-', '-', '2018-09-12 02:22:49'),
(67, 'Gelang', 2, 0, 0, 0, 1800, '-', '-', '2018-09-12 02:23:07'),
(68, 'Gelang', 4, 0, 0, 0, 1800, '-', '-', '2018-09-12 02:23:25'),
(69, 'Gelang', 5, 0, 0, 0, 1800, '-', '-', '2018-09-12 02:23:46'),
(70, 'Gelang', 6, 0, 0, 0, 1800, '0', '-', '2018-09-12 02:23:58'),
(71, 'Gelang', 3, 0, 0, 0, 1800, '-', '-', '2018-09-12 02:24:11'),
(72, 'Rekam Medis', 7, NULL, 0, 0, 7000, '0', '', '2020-01-02 07:55:07'),
(73, 'Materai', 7, NULL, 0, 0, 6000, '0', '', '2020-01-03 02:04:17'),
(74, 'Ambulance', 7, NULL, 0, 0, 0, '0', '', '2020-01-03 02:05:07');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tindakan_medis_non_operatif`
--

CREATE TABLE `tindakan_medis_non_operatif` (
  `id_tindakan` int(11) NOT NULL,
  `kode_tindakan` varchar(20) NOT NULL DEFAULT '-',
  `nama_tindakan` varchar(255) NOT NULL,
  `kelas_id` int(11) NOT NULL,
  `jrs` double NOT NULL COMMENT 'dalam persentase',
  `drOP` double NOT NULL COMMENT 'value dibagi dengan 177 dikalikan total',
  `drANAS` double NOT NULL COMMENT 'value dibagi dengan 177 dikalikan total',
  `perawatOK` double NOT NULL COMMENT 'value dibagi dengan 177 dikalikan total',
  `perawatANAS` double NOT NULL COMMENT 'value dibagi dengan 177 dikalikan total',
  `total` double NOT NULL COMMENT 'dalam persentase',
  `tarip` double NOT NULL,
  `created` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `tindakan_medis_non_operatif`
--

INSERT INTO `tindakan_medis_non_operatif` (`id_tindakan`, `kode_tindakan`, `nama_tindakan`, `kelas_id`, `jrs`, `drOP`, `drANAS`, `perawatOK`, `perawatANAS`, `total`, `tarip`, `created`) VALUES
(2, 'jrm', 'Jasa Rumah Sakit', 6, 0, 0, 0, 0, 0, 0, 0, '2017-01-13 23:33:57'),
(3, 'jm', 'Jasa Medik', 6, 0, 0, 0, 0, 0, 0, 0, '2017-01-13 23:33:57'),
(6, 'japel', 'Jasa Pelayanan Perawatan', 6, 0, 0, 0, 0, 0, 0, 0, '2017-01-13 23:33:57'),
(7, 'monitor', 'Monitor ', 6, 0, 0, 0, 0, 0, 0, 0, '2018-09-13 03:10:51'),
(8, 'ponek', 'Ponek', 6, 0, 0, 0, 0, 0, 0, 0, '2018-09-13 03:11:21'),
(9, 'rr', 'Recovery Room', 6, 0, 0, 0, 0, 0, 0, 0, '2019-03-29 06:29:12');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tindakan_medis_operatif`
--

CREATE TABLE `tindakan_medis_operatif` (
  `id_tindakan` int(11) NOT NULL,
  `nama_tindakan` varchar(255) NOT NULL,
  `kode_tindakan` varchar(10) NOT NULL,
  `kelas_id` int(11) NOT NULL,
  `jrs` double NOT NULL COMMENT 'dalam persentase',
  `drOP` double NOT NULL COMMENT 'value dibagi dengan 177 dikalikan total',
  `drANAS` double NOT NULL COMMENT 'value dibagi dengan 177 dikalikan total',
  `perawatOK` double NOT NULL COMMENT 'value dibagi dengan 177 dikalikan total',
  `perawatANAS` double NOT NULL COMMENT 'value dibagi dengan 177 dikalikan total',
  `total` double NOT NULL COMMENT 'dalam persentase',
  `tarip` double NOT NULL,
  `created` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `tindakan_medis_operatif`
--

INSERT INTO `tindakan_medis_operatif` (`id_tindakan`, `nama_tindakan`, `kode_tindakan`, `kelas_id`, `jrs`, `drOP`, `drANAS`, `perawatOK`, `perawatANAS`, `total`, `tarip`, `created`) VALUES
(7, 'Bahan Habis Pakai RR', 'BHP', 6, 0, 0, 0, 0, 0, 0, 0, '2017-01-14 06:32:42'),
(8, 'Jasa Rumah Sakit', 'JRS', 6, 0, 0, 0, 0, 0, 0, 0, '2017-01-14 06:33:57'),
(9, 'Jasa Medik', 'JMO', 6, 0, 0, 0, 0, 0, 0, 0, '2017-01-14 06:33:57'),
(10, 'JM Anestesi', 'JMA', 6, 0, 0, 0, 0, 0, 0, 0, '2017-01-14 06:33:57'),
(11, 'JM Prwt Anestesi', 'JPA', 6, 0, 0, 0, 0, 0, 0, 0, '2017-01-14 06:33:57'),
(12, 'J-Pel Perawatan OK', 'JPO', 6, 0, 0, 0, 0, 0, 0, 0, '2017-01-14 06:33:57'),
(13, 'RR-Askep', 'RRA', 6, 0, 0, 0, 0, 0, 0, 0, '2017-01-19 03:43:19'),
(14, 'RR-Mntr', 'RRM', 6, 0, 0, 0, 0, 0, 0, 0, '2017-01-19 03:43:27'),
(15, 'Bahan Habis Pakai OK', 'BHP', 6, 0, 0, 0, 0, 0, 0, 0, '2019-02-21 07:48:25');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tindakan_medis_penunjang`
--

CREATE TABLE `tindakan_medis_penunjang` (
  `id_tindakan_penunjang` int(11) NOT NULL,
  `nama_tindakan` varchar(255) NOT NULL,
  `kelas_id` int(11) NOT NULL,
  `bhp` double DEFAULT 0,
  `jrs` double DEFAULT 0 COMMENT 'dalam rupiah',
  `japel` double DEFAULT 0 COMMENT 'dalam rupiah',
  `tarip` double DEFAULT 0,
  `param` varchar(255) DEFAULT NULL COMMENT 'jenis tindakan, contoh : non operatif, bidan, gigi, dsb',
  `catatan` varchar(255) DEFAULT NULL,
  `created` timestamp NULL DEFAULT current_timestamp(),
  `jenis_penunjang` int(11) DEFAULT 1 COMMENT '0 = radiologi, 1= yg lain, 2 = patoklinik, 3 = patoanatomi'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `tindakan_medis_penunjang`
--

INSERT INTO `tindakan_medis_penunjang` (`id_tindakan_penunjang`, `nama_tindakan`, `kelas_id`, `bhp`, `jrs`, `japel`, `tarip`, `param`, `catatan`, `created`, `jenis_penunjang`) VALUES
(27, 'USG', 6, 0, 0, 0, 0, '-', '-', '2017-10-03 08:51:08', 0),
(28, 'Foto', 6, 0, 0, 0, 0, '-', '-', '2017-01-14 06:54:07', 0),
(29, 'CT SCAN', 6, 0, 0, 0, 0, '-', '-', '2017-01-14 06:55:20', 0),
(30, 'Laboratorium', 6, 0, 0, 0, 0, '-', '-', '2017-01-14 06:55:20', 2),
(31, 'EKG', 6, 0, 0, 0, 0, '-', '-', '2017-01-14 06:55:20', 1),
(32, 'HD', 6, 0, 0, 0, 0, '-', '-', '2017-01-14 06:55:20', 4),
(33, 'PA', 6, 0, 0, 0, 0, '-', '-', '2017-01-14 06:55:20', 3),
(34, 'Rehab Medik', 6, 0, 0, 0, 0, '-', '-', '2017-01-14 06:55:20', 1),
(35, 'VISUM', 6, 0, 0, 0, 31500, '-', '-', '2017-09-07 04:01:39', 1),
(36, 'C-Arm', 6, 0, 0, 0, 0, NULL, NULL, '2019-11-25 13:02:25', 1),
(37, 'Mammografi', 6, 0, 0, 0, 0, NULL, NULL, '2019-11-25 13:02:46', 1),
(38, 'Panoramic', 6, 0, 0, 0, 0, NULL, NULL, '2019-11-25 13:02:57', 1),
(39, 'Polos', 6, 0, 0, 0, 0, NULL, NULL, '2019-11-25 13:03:04', 1),
(40, 'Radiografi Kontras', 6, 0, 0, 0, 0, NULL, NULL, '2019-11-25 13:03:13', 1),
(41, 'Radiografi Polos', 6, 0, 0, 0, 0, NULL, NULL, '2019-11-25 13:03:22', 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tindakan_rawat_darurat`
--

CREATE TABLE `tindakan_rawat_darurat` (
  `id_tindakan` int(11) NOT NULL,
  `nama_tindakan` varchar(255) DEFAULT NULL,
  `jrs` double DEFAULT NULL,
  `japel_dokter` double DEFAULT NULL,
  `japel_askep` double DEFAULT NULL,
  `tarip` double DEFAULT NULL,
  `catatan` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `tindakan_rawat_darurat`
--

INSERT INTO `tindakan_rawat_darurat` (`id_tindakan`, `nama_tindakan`, `jrs`, `japel_dokter`, `japel_askep`, `tarip`, `catatan`) VALUES
(1, 'Pemeriksaan', 12000, 12000, 12000, 36000, NULL),
(2, 'Observasi', 19200, 6400, 6400, 32000, NULL),
(3, 'Kecil', 1440, 1440, 1120, 4000, 'Tindakan Medis'),
(4, 'Pengawasan Dokter', 0, 0, 0, 44000, NULL);

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `USERNAME` varchar(100) NOT NULL,
  `PASSWORD` varchar(100) NOT NULL,
  `LEVEL` int(11) NOT NULL COMMENT '1=superadmin, 2=pendaftaran, 3=rekam medis, 4 = keuangan',
  `STATUS` int(11) NOT NULL,
  `PEGAWAI_ID` varchar(20) NOT NULL,
  `euid` int(11) DEFAULT 0,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`USERNAME`, `PASSWORD`, `LEVEL`, `STATUS`, `PEGAWAI_ID`, `euid`, `created_at`, `updated_at`) VALUES
('admin', '19984dcaea13176bbb694f62ba6b5b35', 1, 1, 'root', 2, '2018-12-06 02:56:48', '2020-03-02 09:04:37'),
('agung', '0c0354e4086944701abc27720ac412e0', 4, 1, 'PEG00000000000150304', 0, '2018-12-06 02:56:48', '2018-12-06 02:56:48'),
('aulia', '614913bc360cdfd1c56758cb87eb9e8f', 7, 1, 'PEG00000000000837295', 4, '2018-12-06 02:56:48', '2018-12-06 02:56:48'),
('bpjs', 'a1f271da01cbb49872f0cb0a38e411e1', 16, 1, 'PEG00000000000159284', 2, '2019-12-09 01:31:26', '2019-12-09 01:31:26'),
('cempaka', 'd4862d8213cff5b57b4ec44e0bd516a8', 5, 1, 'PEG00000000000356840', 2, '2018-12-06 02:56:48', '2018-12-06 02:56:48'),
('cendanalantai2', 'd340953b160fad6eb5666d058e035518', 5, 1, 'PEG00000000000504953', 2, '2019-02-18 06:47:07', '2019-02-18 06:47:07'),
('cssd', 'cfafeffb4c0bc6de42893cce081310aa', 19, 1, 'PEG00000000000530517', 2, '2020-04-01 08:00:00', '2020-04-01 08:00:00'),
('danang', '3485669936f0978fa215beb74472c9c0', 17, 1, 'PEG00000000000982909', 2, '2021-06-29 03:15:31', '2021-06-29 03:15:31'),
('farmasikasir', '2039206b3550f338253ca4ed84b33e17', 4, 1, 'PEG00000000000837295', 0, '2018-12-06 02:56:48', '2018-12-06 02:56:48'),
('flamboyan', 'ca5111a9ac47dece0d91134d98d4803e', 5, 1, 'PEG00000000000581242', 2, '2018-12-06 02:56:48', '2018-12-06 02:56:48'),
('garuda', '586293e168054f480d08e30fba98c295', 5, 1, 'PEG00000000000000004', 2, '2018-12-06 02:56:48', '2018-12-06 02:56:48'),
('garudas', '9501bdf832cdfcbd2a75dca830f8b836', 5, 1, 'PEG00000000000000004', 0, '2018-12-06 02:56:48', '2018-12-06 02:56:48'),
('hemodialisa', 'a77f8a8a7d904246d7bb58cf9443ad61', 5, 1, 'PEG00000000000371244', 2, '2020-03-20 01:16:18', '2020-03-20 01:16:18'),
('hemodialisis', '2abee0e8b10c9a1201c9fba6319b7086', 2, 1, 'PEG00000000000470392', 2, '2020-05-12 03:59:53', '2020-05-12 03:59:53'),
('hermawan', '0a5c2657a27501b02b270ca999b0d412', 13, 1, 'PEG00000000000929579', 2, '2019-05-15 04:02:31', '2019-05-15 04:02:31'),
('ICU', 'f8eaf860ef6bf14b6a52fdf35a5190fd', 5, 1, 'PEG00000000000305016', 2, '2018-12-06 02:56:48', '2018-12-06 02:56:48'),
('icucovid19', '30561b5e495e17e274ff51a3be23e78d', 5, 1, 'PEG00000000000400001', 2, '2021-08-25 03:26:01', '2021-08-25 03:26:01'),
('IGD', '382ff9b65a0bf6fdaddb5413d55663ef', 4, 1, 'PEG00000000000000048', 2, '2018-12-06 02:56:48', '2018-12-06 02:56:48'),
('imron', 'f55c882496ad5f94f1f0fc6f47857f22', 6, 1, 'PEG00000000000000042', 2, '2018-12-06 02:56:48', '2018-12-06 02:56:48'),
('informasi', '0dc91b22b7908d2f5cd80e6cc631cd79', 18, 1, 'PEG00000000000762500', 2, '2020-03-09 03:25:30', '2020-03-09 03:25:30'),
('kakasir', '061e6c1872862d210eb6dea2d9ca6f84', 11, 1, 'PEG00000000000992351', 0, '2018-12-06 02:56:48', '2018-12-06 02:56:48'),
('kasir', 'ddb14c5212bfcae591b603177d901667', 4, 1, 'PEG00000000000000002', 0, '2018-12-06 02:56:48', '2018-12-06 02:56:48'),
('kasirayu', '96f39baa83b3b09607c336b7a6a80df3', 4, 1, 'PEG00000000000400001', 0, '2018-12-06 02:56:48', '2018-12-06 02:56:48'),
('kasirdiana', 'bd4995e2a15009e2febf530131804a32', 4, 1, 'PEG00000000000400002', 0, '2018-12-06 02:56:48', '2018-12-06 02:56:48'),
('kasirdwiyanti', '5346449c88139ce868bbc6afe1e0dcc1', 4, 1, 'PEG00000000000400003', 0, '2018-12-06 02:56:48', '2018-12-06 02:56:48'),
('kasirendang', '353c503374dea7f168368c574a505062', 4, 1, 'PEG00000000000000017', 0, '2018-12-06 02:56:48', '2018-12-06 02:56:48'),
('kasirhadi', '17ac944a32e4d7ff02c335ed2bd577c3', 4, 1, 'PEG00000000000000016', 0, '2018-12-06 02:56:48', '2018-12-06 02:56:48'),
('kasirindraningsih', '2e1440b7adccfee2f2d32f59f0759038', 4, 1, 'PEG00000000000000018', 0, '2018-12-06 02:56:48', '2018-12-06 02:56:48'),
('kasirindriyani', '1670423d07f68567b60428c2e43f4bbb', 4, 1, 'PEG00000000000400004', 0, '2018-12-06 02:56:48', '2018-12-06 02:56:48'),
('kasiriwan', '0d74d6b5674f4ac377dc21a29da5a7c6', 4, 1, 'PEG00000000000400005', 0, '2018-12-06 02:56:48', '2018-12-06 02:56:48'),
('kasirkhoirul', 'e8431244c2e8ed95f4f2e64d6e42dbe4', 4, 1, 'PEG00000000000400006', 0, '2018-12-06 02:56:48', '2018-12-06 02:56:48'),
('kasiryuli', 'bc6f4e59cf09d988010f420739e5b859', 4, 1, 'PEG00000000000000020', 0, '2018-12-06 02:56:48', '2018-12-06 02:56:48'),
('laboran', '6685f00d07945ccaef2097ce44b9c0d4', 14, 1, 'PEG00000000000344325', 2, '2019-06-20 04:48:57', '2019-06-20 04:48:57'),
('loketigd', '1acc458dcda02879005b4e78d297beb5', 2, 1, 'PEG00000000000853592', 2, '2020-02-14 11:11:33', '2020-02-14 11:11:33'),
('mawar', 'f0b7ff79da0d7d07f6fc3c8178572842', 5, 1, 'PEG00000000000344191', 0, '2018-12-06 02:56:48', '2018-12-06 02:56:48'),
('MELATI', '5834b6a51b4ee5bb6f8c478dab09908e', 5, 1, 'PEG00000000000503049', 2, '2018-12-06 02:56:48', '2018-12-06 02:56:48'),
('nugroho', '99b2752f06c48a01f445a1e19b910e24', 3, 1, 'PEG00000000000000001', 0, '2018-12-07 02:04:31', '2018-12-07 02:04:31'),
('nurhadi', '808f453201e92ef081d30f744e2e2022', 3, 1, 'PEG00000000000000009', 2, '2018-12-06 02:56:48', '2018-12-06 02:56:48'),
('nusaindah', 'f94aa48a5076451ab3364d01116bb190', 5, 1, 'PEG00000000000072668', 2, '2018-12-06 02:56:48', '2018-12-06 02:56:48'),
('okcentral', '51d19b60fd000071e9c74caf58c247fe', 9, 1, 'PEG00000000000411678', 0, '2018-12-06 02:56:48', '2018-12-06 02:56:48'),
('pendaftaran', 'beb9fb4aa4fbb632a8e029ca1c63e6af', 2, 1, 'PEG00000000000000001', 2, '2018-12-06 02:56:48', '2018-12-06 02:56:48'),
('POLI ABGYN', '6b2f9d24b31707a613a419d6c228f760', 12, 1, 'PEG00000000000501766', 2, '2018-12-06 06:57:57', '2018-12-06 06:57:57'),
('POLI ANAK', '6ab1490122258774067f8e8f9d64cb59', 12, 1, 'PEG00000000000390182', 2, '2018-12-06 06:49:31', '2018-12-06 06:49:31'),
('POLI BEDAH ANAK', '89888285451598e4d5def7741d072f75', 12, 1, 'PEG00000000000137408', 2, '2021-06-28 04:35:33', '2021-06-28 04:35:33'),
('POLI BEDAH MULUT', 'c4b55e335aaffab33705ddb0677d03f1', 12, 1, 'PEG00000000000238486', 2, '2018-12-06 06:52:05', '2018-12-06 06:52:05'),
('POLI BEDAH SYARAF', '5418d280cf7e00da7c56f4b87fde2794', 12, 1, 'PEG00000000000322953', 2, '2022-10-21 02:27:34', '2022-10-21 02:27:34'),
('POLI BEDAH TULANG', 'fe19bf8655db4aedadfa2ed666f16ae4', 12, 1, 'PEG00000000000264714', 2, '2018-12-06 06:52:56', '2018-12-06 06:52:56'),
('POLI BEDAH UMUM', '2d0b814738b6e3f1f207b4e906af9516', 12, 1, 'PEG00000000000093167', 2, '2018-12-06 06:53:38', '2018-12-06 06:53:38'),
('POLI FISIOTERAPI', 'ae5ba5a4eec830204efe04ba982da88f', 12, 1, 'PEG00000000000397829', 2, '2020-03-13 02:08:07', '2020-03-13 02:08:07'),
('POLI GIGI', '1c96661e4fdf2d073a068f265c5f98fb', 12, 1, 'PEG00000000000504928', 2, '2018-12-06 06:54:15', '2018-12-06 06:54:15'),
('POLI INTERNE', '29f8a1bca13b84eebb3753f09219fffa', 12, 1, 'PEG00000000000251606', 2, '2018-12-06 02:56:48', '2021-05-05 05:05:43'),
('POLI JANTUNG', 'd999e95b8953685bf96795eacb03f557', 12, 1, 'PEG00000000000360478', 2, '2018-12-06 06:54:58', '2018-12-06 06:54:58'),
('POLI JIWA', 'c1be8517325eed6c90cc426bd8f88069', 12, 1, 'PEG00000000000235222', 2, '2018-12-06 06:55:44', '2018-12-06 06:55:44'),
('POLI KULIT KELAMIN', '9f17498e3578bdca41a67f50fb922aa0', 12, 1, 'PEG00000000000314354', 2, '2018-12-06 06:56:19', '2018-12-06 06:56:19'),
('POLI MATA', '7cef3c0bc8bb3160da9f18fe8e820bed', 12, 1, 'PEG00000000000304580', 2, '2018-12-06 06:57:18', '2018-12-06 06:57:18'),
('POLI ORTODENTIK', 'bf6d64e71c26df29b2ecad0cd847bf09', 12, 1, 'PEG00000000000778574', 2, '2018-12-06 06:58:40', '2018-12-06 06:58:40'),
('POLI PARU', '3e3eb6b1719834f14198be697d9d3805', 12, 1, 'PEG00000000000773867', 2, '2018-12-06 06:59:15', '2018-12-06 06:59:15'),
('POLI PEMERIKSAAN KESEHATAN', '40bba34d1132ceaa663a9cae10bdfcca', 12, 1, 'PEG00000000000980941', 2, '2018-12-06 07:00:13', '2018-12-06 07:00:13'),
('POLI SYARAF', '29cddd7f7aa123c8472d00b178925507', 12, 1, 'PEG00000000000387639', 2, '2018-12-06 07:00:50', '2018-12-06 07:00:50'),
('POLI THT', '8f79f187c72ff005ca2a93a1d262face', 12, 1, 'PEG00000000000498193', 2, '2018-12-06 07:01:44', '2018-12-06 07:01:44'),
('POLI UROLOGI', '6856c953ea23be9bff18123f4c71e8bb', 12, 1, 'PEG00000000000151665', 2, '2018-12-06 07:02:24', '2018-12-06 07:02:24'),
('POLI VCT', 'eb93f2c4c936d205ead184945c2701b4', 12, 1, 'PEG00000000000305454', 2, '2018-12-06 07:02:59', '2018-12-06 07:02:59'),
('POLIEDODONSI', '75917df5fe43ca7345d463ea13260d1d', 12, 1, 'PEG00000000000512943', 2, '2021-03-23 03:37:00', '2021-03-23 03:37:00'),
('poliinterne', 'd999e95b8953685bf96795eacb03f557', 12, 1, 'PEG00000000000360478', 2, '2018-12-06 06:54:58', '2018-12-06 06:54:58'),
('radiologi', '0cc175b9c0f1b6a831c399e269772661', 8, 1, 'PEG00000000000982909', 2, '2021-06-29 12:33:46', '2021-06-29 12:33:46'),
('Roza', '3e48bf11dacddf353350b4e27ca7478f', 4, 1, 'PEG00000000000000043', 17, '2022-12-20 01:09:18', '2022-12-20 01:09:18'),
('RR', '514f1b439f404f86f77090fa9edc96ce', 15, 1, 'PEG00000000000982908', 2, '2018-12-06 02:56:48', '2018-12-06 02:56:48'),
('seruni', '525f9ffa28868c31b87583056b14aba8', 5, 1, 'PEG00000000000561326', 0, '2018-12-06 02:56:48', '2018-12-06 02:56:48'),
('sujiman', '3f61c604d75c22b5a679bf3fbb110a5a', 5, 1, 'PEG00000000000396395', 0, '2018-12-06 02:56:48', '2018-12-06 02:56:48'),
('tanjung', '7aa2602c588c05a93baf10128861aeb9', 5, 1, 'PEG00000000000406088', 0, '2018-12-06 02:56:48', '2018-12-06 02:56:48'),
('tempkakasir', 'b37517217b48a135d5a463bb39e88814', 11, 1, 'PEG00000000000837295', 2, '2019-06-05 06:39:11', '2019-06-05 06:39:11'),
('teratai', '80a1687dfe3874ea3bc669dfbfa2046b', 5, 1, 'PEG00000000000583742', 2, '2018-12-06 02:56:48', '2018-12-06 02:56:48');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user_level`
--

CREATE TABLE `user_level` (
  `KODE_LEVEL` int(11) NOT NULL,
  `NAMA_LEVEL` varchar(50) NOT NULL,
  `STATUS_LEVEL` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `user_level`
--

INSERT INTO `user_level` (`KODE_LEVEL`, `NAMA_LEVEL`, `STATUS_LEVEL`) VALUES
(1, 'SUPER ADMIN', 0),
(2, 'PENDAFTARAN', 0),
(3, 'REKAM MEDIS', 0),
(4, 'KASIR', 0),
(5, 'OPERATOR KAMAR', 0),
(6, 'KEUANGAN', 0),
(7, 'FARMASI', 0),
(8, 'RADIOLOGI', 0),
(9, 'OPERASI', 0),
(10, 'IGD', 0),
(11, 'KA KASIR', 0),
(12, 'POLI', 0),
(13, 'DIREKTUR', 0),
(14, 'LABORAN', 0),
(15, 'RR', 0),
(16, 'BPJS', 0),
(17, 'DOKTER', 0),
(18, 'INFORMASI', 0),
(19, 'CSSD', 0);

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `dm_tindakan`
--
ALTER TABLE `dm_tindakan`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indeks untuk tabel `tindakan_medis_lain`
--
ALTER TABLE `tindakan_medis_lain`
  ADD PRIMARY KEY (`id_tindakan`) USING BTREE,
  ADD KEY `tindakan_medis_lain_ibfk_1` (`kelas_id`) USING BTREE;

--
-- Indeks untuk tabel `tindakan_medis_non_operatif`
--
ALTER TABLE `tindakan_medis_non_operatif`
  ADD PRIMARY KEY (`id_tindakan`) USING BTREE,
  ADD KEY `tindakan_medis_operatif_ibfk_1` (`kelas_id`) USING BTREE;

--
-- Indeks untuk tabel `tindakan_medis_operatif`
--
ALTER TABLE `tindakan_medis_operatif`
  ADD PRIMARY KEY (`id_tindakan`) USING BTREE,
  ADD KEY `tindakan_medis_operatif_ibfk_1` (`kelas_id`) USING BTREE;

--
-- Indeks untuk tabel `tindakan_medis_penunjang`
--
ALTER TABLE `tindakan_medis_penunjang`
  ADD PRIMARY KEY (`id_tindakan_penunjang`) USING BTREE,
  ADD KEY `tindakan_medis_penunjang_ibfk_1` (`kelas_id`) USING BTREE;

--
-- Indeks untuk tabel `tindakan_rawat_darurat`
--
ALTER TABLE `tindakan_rawat_darurat`
  ADD PRIMARY KEY (`id_tindakan`) USING BTREE;

--
-- Indeks untuk tabel `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`USERNAME`) USING BTREE,
  ADD KEY `PEGAWAI_ID` (`PEGAWAI_ID`) USING BTREE,
  ADD KEY `LEVEL` (`LEVEL`) USING BTREE;

--
-- Indeks untuk tabel `user_level`
--
ALTER TABLE `user_level`
  ADD PRIMARY KEY (`KODE_LEVEL`) USING BTREE;

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `dm_tindakan`
--
ALTER TABLE `dm_tindakan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT untuk tabel `tindakan_medis_lain`
--
ALTER TABLE `tindakan_medis_lain`
  MODIFY `id_tindakan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=75;

--
-- AUTO_INCREMENT untuk tabel `tindakan_medis_non_operatif`
--
ALTER TABLE `tindakan_medis_non_operatif`
  MODIFY `id_tindakan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT untuk tabel `tindakan_medis_operatif`
--
ALTER TABLE `tindakan_medis_operatif`
  MODIFY `id_tindakan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT untuk tabel `tindakan_medis_penunjang`
--
ALTER TABLE `tindakan_medis_penunjang`
  MODIFY `id_tindakan_penunjang` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT untuk tabel `tindakan_rawat_darurat`
--
ALTER TABLE `tindakan_rawat_darurat`
  MODIFY `id_tindakan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `tindakan_medis_lain`
--
ALTER TABLE `tindakan_medis_lain`
  ADD CONSTRAINT `tindakan_medis_lain_ibfk_1` FOREIGN KEY (`kelas_id`) REFERENCES `dm_kelas` (`id_kelas`);

--
-- Ketidakleluasaan untuk tabel `tindakan_medis_non_operatif`
--
ALTER TABLE `tindakan_medis_non_operatif`
  ADD CONSTRAINT `tindakan_medis_non_operatif_ibfk_1` FOREIGN KEY (`kelas_id`) REFERENCES `dm_kelas` (`id_kelas`);

--
-- Ketidakleluasaan untuk tabel `tindakan_medis_operatif`
--
ALTER TABLE `tindakan_medis_operatif`
  ADD CONSTRAINT `tindakan_medis_operatif_ibfk_1` FOREIGN KEY (`kelas_id`) REFERENCES `dm_kelas` (`id_kelas`);

--
-- Ketidakleluasaan untuk tabel `tindakan_medis_penunjang`
--
ALTER TABLE `tindakan_medis_penunjang`
  ADD CONSTRAINT `tindakan_medis_penunjang_ibfk_1` FOREIGN KEY (`kelas_id`) REFERENCES `dm_kelas` (`id_kelas`);

--
-- Ketidakleluasaan untuk tabel `user`
--
ALTER TABLE `user`
  ADD CONSTRAINT `user_ibfk_1` FOREIGN KEY (`LEVEL`) REFERENCES `user_level` (`KODE_LEVEL`),
  ADD CONSTRAINT `user_ibfk_2` FOREIGN KEY (`PEGAWAI_ID`) REFERENCES `tpegawai` (`KDPEGAWAI`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
